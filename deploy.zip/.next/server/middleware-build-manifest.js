globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/b5a99b5d377a6d81.js",
      "static/chunks/turbopack-43fc531073bd2e75.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/b5a99b5d377a6d81.js",
      "static/chunks/turbopack-2282de2d4e471671.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/ef5e44d9bfbfc8b9.js",
    "static/chunks/980a40ab20ad0eec.js",
    "static/chunks/202abb9aed9e828b.js",
    "static/chunks/0656f51f27ce398d.js",
    "static/chunks/turbopack-f6e90fc26e2bb685.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];