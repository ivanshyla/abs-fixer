var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/getimg-inpaint/route.js")
R.c("server/chunks/[root-of-the-server]__65ad6663._.js")
R.c("server/chunks/node_modules_next_dist_4ac85b6e._.js")
R.c("server/chunks/node_modules_next_48b9435f._.js")
R.m(21633)
R.m(18027)
module.exports=R.m(18027).exports
