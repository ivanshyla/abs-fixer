var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/inpaint/route.js")
R.c("server/chunks/[root-of-the-server]__c9a44b65._.js")
R.c("server/chunks/node_modules_next_dist_4ac85b6e._.js")
R.c("server/chunks/node_modules_e9ce99a6._.js")
R.m(48897)
R.m(97294)
module.exports=R.m(97294).exports
