var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/fal-inpaint/route.js")
R.c("server/chunks/[root-of-the-server]__2013b725._.js")
R.c("server/chunks/node_modules_76354604._.js")
R.c("server/chunks/node_modules_next_dist_4ac85b6e._.js")
R.c("server/chunks/node_modules_next_48b9435f._.js")
R.m(38746)
R.m(56877)
module.exports=R.m(56877).exports
