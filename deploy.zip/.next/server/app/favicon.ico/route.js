var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__5c31121b._.js")
R.c("server/chunks/node_modules_next_dist_77fd8386._.js")
R.c("server/chunks/node_modules_next_dist_03a3c8f9._.js")
R.c("server/chunks/node_modules_next_32887987._.js")
R.m(15934)
R.m(73932)
module.exports=R.m(73932).exports
